# SC_Hackathon
This is project submission for Standard Chartered off campus Diversity Hackathon 2022. This is solution to problem statement ~ Campaign Management Platform for Women. 
Landing Page is index1.html.
